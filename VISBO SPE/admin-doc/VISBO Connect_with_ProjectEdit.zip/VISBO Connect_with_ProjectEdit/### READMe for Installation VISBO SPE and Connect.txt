### READMe for Installation VISBO SPE and Connect

Here's a description of what this script does:

1. Extracting Installation Files:
   - Extracts "VISBO SPE.zip" and "VISBO Connect.zip" if present
   - Uses Windows' built-in extraction functionality

2. VISBO Project Edit Installation:
   - Creates a directory under %AppData%\VISBO
   - Copies the Excel file "VISBO Project Edit.xlsx" and its icon
   - Creates a desktop shortcut

3. VISBO Connect Installation:
   - Locates the installed Excel path in Windows registry
   - Creates a configuration file (vcn_config.json) containing Excel and file paths
   - Creates another desktop shortcut

4. Excel Security Settings:
   - Detects installed Office version
   - Offers two options for Excel Trust Center configuration:
     a) Automatic via registry entry (including backup of previous settings)
     b) Manual configuration with step-by-step instructions
   - Adds the VISBO folder as a trusted location in Excel

This setup is necessary to ensure the VISBO Excel add-ins can run without security warnings and all components work together properly.